INSERT INTO driver (id, first_name, last_name, vehicle_id) VALUES
  (0, 'Gigi', 'Wentworth (877-CASH-NOW)', 0),
  (1, 'Fu', 'Duh', 1),
  (2, 'Joe', 'Schmo', 2);
